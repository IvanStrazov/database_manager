# utf-8
# Python 3.7
# 2021-03-01


__version__ = "1.3"
